//Kerry Gip
//CSCI 3543 
//Lab 1a
#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <sys/utsname.h>
#include <ctime>

using namespace std;

int main() {

	cout << "\nLAB 1: PART A" << endl << endl; 
	struct utsname name;

  	errno = 0;
  	if (uname(&name) != 0) {
     	perror("uname");
 	exit(EXIT_FAILURE);
}		
  
	cout << "System name: "<< name.sysname << endl;
	cout << "Mode name: " <<  name.nodename << endl;
	cout << "Release: " << name.release << endl;
	cout << "Version: " << name.version << endl;
	cout << "Machine: " << name.machine << endl << endl << endl;

	cout << "LAB 1: PART B-1" << endl << endl; 

		
	ifstream infile("/proc/stat");
	string line, line2, line3, line4;
	int lineNum, lineNum4; 
	
	string ignore;
	//https://stackoverflow.com/questions/32557353/c-easy-way-to-ignore-first-word-of-input
	while(lineNum !=6 && infile >> ignore,getline(infile,line)){	
		++lineNum;	

		if (lineNum == 6){
			cout << line << " seconds since EPOCH" << endl;
			//convert epoch to time
			
			//insert epoch converter 
			//https://stackoverflow.com/questions/1692184/converting-epoch-time-to-real-date-time
			time_t line = time(NULL);
			cout << "Current time: " << asctime(gmtime(&line));

			//time conversion 
			int convertLine = line;
			
			int yearLine, monthLine, dayLine, hourLine, minLine, secLine;
			yearLine = convertLine/31556952 + 1969;
			monthLine = convertLine/2629746/60;
			dayLine = convertLine/60/60/1000/24; 
			hourLine = convertLine/60/60%24;
			minLine = convertLine/60%60;
			secLine = convertLine%60;
				//<< yearLine << "-" << monthLine << "-" << dayLine << "  " << hourLine  << ":" << minLine  << ":" << secLine  << endl << endl;
	
	//https://www.epochconverter.com/programming/c
	time_t timeEpoch = 1603737816;
    	struct tm  timestamp;
    	char   epoc[80];

    // Format time, "ddd yyyy-mm-dd hh:mm:ss zzz"
    	timestamp = *localtime(&timeEpoch);
    	strftime(epoc, sizeof(epoc), "%a %Y-%m-%d %H:%M:%S %Z", &timestamp);
    	cout << "Converted time since start: "<< epoc << endl;
			

		}
		

	}
	infile.close();
	

	cout << "\nLAB 1: PART B-2" << endl << endl; 
	ifstream infile2("/proc/uptime");
	//This file contains two numbers: the uptime of the system in seconds and the amount of time spent in idle process in seconds. 
	//Display the amount of time since system was last booted in the form dd:hh:mm:ss.
	//uptime of system - current time 
	
	
	getline(infile2,line2);
	//infile2 >> line2;	
		
	cout << line2 << endl;
	string input = line2;
	https://stackoverflow.com/questions/41992747/how-to-only-print-the-first-word-of-a-string-in-c/41992882
	string uptime = input.substr(0, input.find(" "));
	string idle = input.substr(input.find(" "), input.find(" "));

	cout << "The uptime is: " << uptime << endl;
	cout << "The idle time is : " << idle << endl;

	stringstream a(uptime);
	int intUp = 0;
	a >> intUp;	

	stringstream b(idle);
	int intIdle = 0;
	b >> intIdle;
	

	int convert = intIdle - intUp;
	//time conversion 
	int day, hour, min, sec;
	day = convert/60/60/24;
	hour = convert/60/60%24;
	min = convert/60%60;
	sec = convert%60;

	cout << "Total time since system was last booted: " << day << ":" << hour << ":" << min << ":" << sec << endl << endl;			
	//https://stackoverflow.com/questions/19211518/converting-proc-uptime-to-ddhhmmss
	
	infile2.close();
	

	cout << "\n\nLAB 1: PART B-3" << endl << endl; 
	ifstream infile3("/proc/stat");


	string user, sys;
	getline(infile3, line3);
		cout << "Whole line is: " << line3 << endl;

		
		
				

	//get line 1 and 3
	cout << "The time it has spent in user mode: " << line3.substr(3,10) << endl;
	cout << "The time it has spent in system mode: " << line3.substr(18,9) << endl;


	infile3.close();


	cout << "\nLAB 1: PART B-4" << endl << endl; 
	ifstream infile4("/proc/meminfo");
	//memtotal - memavailable = memfree
	
	int lineNum2 = 0;
	while(lineNum2 !=3 && getline(infile4,line4)){	
		++lineNum2;	
		
		
		if (lineNum2 == 1){
			//memTotal = line4;
			cout << line4 << endl;
			continue;
			}
		else if (lineNum2 == 3){
			
			//memAvail = line4;
			cout << line4 << endl;
			break;
			}
		//break;
			
		
	}
	
	infile4.close();


}





















