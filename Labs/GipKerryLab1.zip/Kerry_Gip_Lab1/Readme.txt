*******************************************************
*  Name      :  Kerry Gip        
*  Student ID:  830354146               
*  Class     :  CSCI 3453        
*  HW#       :  1              
*  Due Date  :  2/14/2021
*******************************************************


                 Read Me


*******************************************************
*  Description of the program
*******************************************************
To understand and gain familiarity with the system call interface in Unix Environment
As well as remember how to use C++. 
Used system calls and proc filesystem to gather info about system


*******************************************************
*  Source files
*******************************************************

Name:  main.cpp
   Main program. Answers part A and B of the lab. 

Name:  
 

Name: 
 
   
   
*******************************************************
*  Circumstances of programs
*******************************************************

   The program runs successfully on a Windows 10 desktop and on CSE Grid's built-in Putty
   
   The program was developed, tested and compiled and ran on CSE Grid's compiler running gnu g++ 6.3.1 


*******************************************************
*  How to build and run the program
*******************************************************

1. Uncompress the homework.  If homework file is compressed, you need to uncompress it. 
   If not skip this step  
   To uncompress it use the following commands 
       % unzip [GipHW1]

   Now you should see a directory named homework with the files:
        main.cpp
        makefile
        Readme.txt

2. Build the program.

    Change to the directory that contains the file by:
    % cd  

    Compile the program either way:
    % typing in the .cpp files
	a. g++ -o app main.cpp  .cpp
	b. make

3. Run the program by:
   % ./app
	If using make: ./execute

4. Delete the obj files, executables, and core dump by
   %./make clean
