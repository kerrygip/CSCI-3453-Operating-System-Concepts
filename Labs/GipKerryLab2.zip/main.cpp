﻿#include <fstream>
#include <iostream>
#include <string>
#include <vector>
#include <sstream>
#include <fstream>
#include <algorithm>
#include <iomanip>

using namespace std;

//alot of these processes are set up the same, so I will not be commenting for each of the functions that are duplicates will also link every single site that ive used. At this point idk where went where, but i looked at it for reference 
//https://www.quora.com/How-do-I-write-a-C++-program-to-implement-a-SRTF-Shortest-Remaining-Time-First-scheduling-algorithm-along-with-displaying-the-Gantt-chart
//


//setting up the struct
struct Process {
    int PID = 0;
    int arrivalTime = 0;
    int burstTime = 0;
    int cpuTime = 0;
    int completion = 0;
    int waitTime = 0;
    int turnaroundTime = 0;
    int contextSwitch = 0;
    int totalTime = 0;

};

//global variables used for each of the functions 
int avgBurst = 0;
int avgWait = 0;
int avgTurn = 0;
int totalContext = 0;

//initialize all the vectors
vector <Process> processQ;
vector <Process> readyQ;
vector <Process> finished;

//instead of making a .h file, I wanted to just put it all here since its just pretty short and simple 
void fcfs(string infileName);
void srtf(string infileName);
void rr(string infileName, int quantum);
void times();



int main(int argc, char* argv[]) {

    string arg1(argv[1]); //for conversions 
    string arg2(argv[2]);

    //FCFS
    if ((arg2 == "FCFS") || (arg2 == "fcfs"))
    {
        char schedule[] = "FCFS";
        fcfs(arg1);
    }

    //SRTF
    else if ((arg2 == "SRTF") || (arg2 == "srtf"))
    {
        char schedule[] = "SRTF";
        srtf(arg1);
    }

    //RR
    else if ((arg2 == "RR") || (arg2 == "rr"))
    {
        //so the error here is that i need to do let it change the rr settings to anything else but 4
        int arg4 = atoi(argv[4]);
        rr(arg1, arg4);
        int quantum = 4;
        
    }
    else
    {
        cout << "Put a space between rr and number ";

    }

}

//You have to implement FCFS (First Come First Serve), SRTF (Shortest Remaining Task
//First   preemptive), and RR(Round Robin) scheduling algorithms.

//https://www.geeksforgeeks.org/program-for-fcfs-cpu-scheduling-set-2-processes-with-different-arrival-times/
//https://www.geeksforgeeks.org/program-for-fcfs-cpu-scheduling-set-1/
//https://www.thecrazyprogrammer.com/2014/11/c-cpp-program-for-first-come-first-served-fcfs.html
// but mostly this guy 
//https://codophobia.github.io/operating%20system/fcfs-scheduling-program/ 

void fcfs(string infileName)
{
    int line = 0;
    int column1 = 0;
    int column2 = 0;
    int currentPID = 0;
    Process current;
    ifstream inFile;
    inFile.open(infileName);
    int processSize = finished.size();

    if (!inFile)
    {
        cout << "Unable to open file";
    }

    //read in the file and initialize 
    while (inFile >> line)
    {
        inFile >> column1;
        inFile >> column2;
        avgBurst = avgBurst + column2;
        Process temp;
        temp.PID = line;
        temp.arrivalTime = column1;
        temp.burstTime = column2;
        processQ.push_back(temp);
    }
    inFile.close();


    //The simulator will display both the history of process, like like Gantt Chart, and collected
// data.The expected output format is as follows :
    cout << "************************************************************" << endl;
    cout << "************Scheduling algorithm : FCFS ********************" << endl;
    cout << "************************************************************ " << endl << endl;


    // sets up the ** count thing 
    currentPID = processQ[0].PID;
    current = processQ[0];
    processQ.erase(processQ.begin());
    cout << "P" << currentPID;

    for (int i = 0; i <= avgBurst; i++)
    {
        // as it iterates through, completion time, current run time increase
        current.completion++;
        current.cpuTime++;
        // burst time decreases with each iteration
        current.burstTime = current.burstTime - 1;
        // iterates through the vectors
        for (int j = 0; j < processQ.size(); j++)
        {
            // if process is greater than arrival time, then we dont use it, it goes ti wait
            if (processQ[j].arrivalTime > i)
                break;
            else
                processQ[j].waitTime++;
            avgWait++;
        }
        //if it completed its burst, then it goes into the finished vector
        if (current.burstTime == 0)
        {
            if (current.burstTime == 0 && processQ.size() == 0)
            {
                finished.push_back(current);
                for (int k = 0; k < finished.size(); k++)
                {
                    //if pid is done, finished goes up
                    if (current.PID == finished[k].PID)
                        finished[k].completion = i + 1;
                }
                break;
            }
            finished.push_back(current);
            
            //https://www.studytonight.com/operating-system/first-come-first-serve
            for (int z = 0; z < finished.size(); z++)
            {
                if (current.PID == finished[z].PID)
                    finished[z].completion = i + 1;
            }
            //empty out the process and print the stars out 
            current = processQ[0];
            processQ.erase(processQ.begin());
            currentPID = current.PID;
            cout << "P" << currentPID;
        }
        else cout << "  ";
    }
    cout << endl << endl;



    //calcuate average wait times 
    //Average CPU burst time
    //Average waiting time
    //Average turn around time
    //Average response time ?? time.time()? 
    //Total number of Context Switching performed
    // 


    for (int x = 0; x < avgBurst; x++)
        cout << "* ";
    cout << "\n(each star represents one ms)\n";


    cout << "|PID| " << "Arrival| " << "CPU-Burst| " << "Completion| "
        << "Wait Time| " << "Turnaround| " << "# of Context-Switch| \n";
    for (int j = 0; j < finished.size(); j++) {
        //setw to make it look pretty
        cout << " " << setw(5) << finished[j].PID
            << " " << setw(7) << finished[j].arrivalTime
            << " " << setw(11) << finished[j].cpuTime
            << " " << setw(10) << finished[j].completion
            << " " << setw(12) << finished[j].waitTime
            << " " << setw(10) << finished[j].completion - finished[j].arrivalTime;
        avgTurn = avgTurn + (finished[j].completion - finished[j].arrivalTime);
        cout << " " << setw(5) << 0 << endl;
    }

    // getting a floating exception 
    //fixed with setprecision
    cout << fixed << setprecision(2) << "\nAverage CPU burst time = " << (float)avgBurst / finished.size() << endl;
    cout << fixed << setprecision(2) << "Average waiting time = " << (float)avgWait / finished.size() << endl;
    cout << fixed << setprecision(2) << "Average turn around time = " << (float)avgTurn / finished.size() << endl;
    cout << fixed << setprecision(2) << "Total Number of Context Switching Performed = " << (float)totalContext / finished.size() << endl << endl;
}


//https://www.geeksforgeeks.org/program-for-shortest-job-first-sjf-scheduling-set-2-preemptive/ and 
// https://cppsecrets.com/users/130697109105116981051151041169798575364103109971051084699111109/C00-Program-of-Shortest-Remaining-Time-FirstSRTF-Scheduling.php
//https://shivammitra.com/operating%20system/srtf-scheduling-program/#

void srtf(string infileName) {
    int line = 0;
    int column1 = 0;
    int column2 = 0;
    int currentPID;
    Process current;
    bool nextProcess = true;
    ifstream inFile;
    inFile.open(infileName);
    int processSize = finished.size();

    if (!inFile)
    {
        cout << "Unable to open file";

    }
    while (inFile >> line)
    {
        inFile >> column1;
        inFile >> column2;
        avgBurst = avgBurst + column2;
        Process temp;
        temp.PID = line;
        temp.arrivalTime = column1;
        temp.burstTime = column2;
        processQ.push_back(temp);
    }
    inFile.close();


    //The simulator will display both the history of process, like like Gantt Chart, and collected
// data.The expected output format is as follows :
    cout << "************************************************************" << endl;
    cout << "************Scheduling algorithm : SRTF ********************" << endl;
    cout << "************************************************************ " << endl << endl;

    currentPID = processQ[0].PID;
    current = processQ[0];
    processQ.erase(processQ.begin());
    cout << "P" << currentPID;

    for (int i = 1; i <= avgBurst; ++i)
    {
        //start everything at 0 and move up from here
        if (processQ.size() == 0) 
        nextProcess = false;
        current.burstTime = current.burstTime - 1;
        current.completion++;
        current.cpuTime++;
        for (int j = 0; j < processQ.size(); j++)
        {
            if (processQ[j].arrivalTime > i) 
                break;
            else
                processQ[j].waitTime++;
            avgWait++;
        }

        for (int k = 0; k < readyQ.size(); k++)
        {
            readyQ[k].waitTime++;
            avgWait++;
        }
        // same setup as fcfs 
        //https://shivammitra.com/operating%20system/srtf-scheduling-program/#
        if (current.burstTime == 0)
        {
            finished.push_back(current);
            for (int z = 0; z < finished.size(); z++)
            {
                if (current.PID == finished[z].PID)
                    finished[z].completion = i + 1;
            }

            if (nextProcess)
            {
                //if the next process has shorter burst time, then we go with the ready q and iterate through that
                if (processQ[0].burstTime > readyQ[0].burstTime)
                {
                    readyQ.push_back(current);
                    current = readyQ[0];
                    readyQ.erase(readyQ.begin());
                    currentPID = current.PID;
                    cout << "P" << currentPID;
                }
                else
                {
                    //if its the same then we continue with what is already iterating 
                    current = processQ[0];
                    processQ.erase(processQ.begin());
                    currentPID = current.PID;
                    cout << "P" << currentPID;
                }
            }
            else if (readyQ.size() != 0)
            {
                //start next iteration if next process in queue can move forward and we start it 
                current = readyQ[0];
                readyQ.erase(readyQ.begin());
                currentPID = current.PID;
                cout << "P" << currentPID;
            }
            else 
                break;

        }
        else if (i == processQ[0].arrivalTime)
        {
            if (processQ[0].burstTime < current.burstTime)
            {
                //for different priorities, push the current process into the ready queue vector 
                readyQ.push_back(current);
                current = processQ[0];
                processQ.erase(processQ.begin());
                currentPID = current.PID;
                cout << "P" << currentPID;
            }
            else
            {
                readyQ.push_back(processQ[0]);
                processQ.erase(processQ.begin());
                cout << "  ";

            }
        }
        else cout << "  ";
    }
    finished.push_back(current);
    cout << endl << endl;


    for (int x = 0; x < avgBurst; x++) cout << "* ";
    cout << "\n(each star represents one ms)\n";


    cout << "|PID|" << "Arrival|" << "CPU-Burst|" << "Finish Time|"
        << "Wait Time|" << "Turnaround|" << "# of Context-Switch|\n";
    for (int j = 0; j < finished.size() - 1; j++) {

        cout << " " << setw(5) << finished[j].PID
            << " " << setw(7) << finished[j].arrivalTime
            << " " << setw(11) << finished[j].cpuTime
            << " " << setw(10) << finished[j].completion
            << " " << setw(12) << finished[j].waitTime
            << " " << setw(10) << finished[j].completion - finished[j].arrivalTime;
        avgTurn = avgTurn + (finished[j].completion - finished[j].arrivalTime);
        cout << " " << setw(5) << 0 << endl;
    }



    cout << fixed << setprecision(2) << "\nAverage CPU burst time = " << (float)avgBurst / finished.size() << endl;
    cout << fixed << setprecision(2) << "Average waiting time = " << (float)avgWait / finished.size() << endl;
    cout << fixed << setprecision(2) << "Average turn around time = " << (float)avgTurn / finished.size() << endl;
    cout << fixed << setprecision(2) << "Total Number of Context Switching Performed = " << 0 << endl << endl;
}


//https://www.geeksforgeeks.org/program-round-robin-scheduling-set-1/
//http://www.cs.trinity.edu/~bmassing/Classes/CS3323_2012fall/Homeworks/HW03/Problems/scheduler/scheduler.cpp
// has issues with not being able to change the quantum 
//https://shivammitra.com/operating%20system/roundrobin-scheduling-program/#
//https://japp.io/algorithms/os-scheduling/round-robin-process-scheduling-algorithm-program-in-c-c/

void rr(string infileName, int quantum)
{
    int quantumTime = quantum;
    int line = 0;
    int column1 = 0;
    int column2 = 0;
    ifstream inFile;
    int currentPID;
    Process current;
    bool nextProcess = true;
    inFile.open(infileName);
    int processSize = finished.size();

    if (!inFile)
    {
        cout << "Unable to open file";

    }
    while (inFile >> line)
    {
        inFile >> column1;
        inFile >> column2;
        avgBurst = avgBurst + column2;
        Process temp;
        temp.PID = line;
        temp.arrivalTime = column1;
        temp.burstTime = column2;
        processQ.push_back(temp);
    }
    inFile.close();

    //The simulator will display both the history of process, like like Gantt Chart, and collected
// data.The expected output format is as follows :
    cout << "************************************************************" << endl;
    cout << "************Scheduling algorithm : ROUND ROBIN *************" << endl;
    cout << "************************************************************ " << endl << endl;

    currentPID = processQ[0].PID;
    current = processQ[0];
    processQ.erase(processQ.begin());
    cout << "P" << currentPID << "";

    for (int i = 0; i <= avgBurst - 1; i++)
    {
        //starting the iteration
        //reducing the quantum time as each iteration goes 
        if (processQ.size() == 0) 
            nextProcess = false;
            quantumTime--;
            current.completion++;
            current.cpuTime++;
            current.burstTime = current.burstTime - 1;

        for (int j = 0; j < processQ.size(); j++)
        {
            //if arrival time is less than iteration, then we dont process it and add to its wait time 
            if (processQ[j].arrivalTime > i) 
                break;
            else
                processQ[j].waitTime++;
            avgWait++;
        }
        //increase everyone elses wait time 
        for (int k = 0; k < readyQ.size(); k++)
        {
            readyQ[k].waitTime++;
            avgWait++;
        }
        //if process is done, we push it finished queue 
        if (current.burstTime == 0)
        {

            finished.push_back(current);
            quantumTime = quantum;
            //restart quantum time
            //count how long it took for process to finish 
            for (int z = 0; z < finished.size(); z++)
            {
                if (current.PID == finished[z].PID)
                    finished[z].completion = i + 1;
            }
            //print out PID on gantt chart
            if (nextProcess && (processQ[0].arrivalTime <= i))
            {
                current = processQ[0];
                processQ.erase(processQ.begin());
                currentPID = current.PID;
                cout << "P" << currentPID << "";
            }
            else if (readyQ.size() != 0)
            {
                current = readyQ[0];
                readyQ.erase(readyQ.begin());
                currentPID = current.PID;
                cout << "P" << currentPID;
            }
            else break;
        }
        else if (quantumTime == 0)
        {
            //if quantum is 0 then we basically restart and move to next process 
            quantumTime = quantum;
            if (nextProcess && (processQ[0].arrivalTime <= i))
            {
                readyQ.push_back(current);
                current = processQ[0];
                processQ.erase(processQ.begin());
                currentPID = current.PID;
                cout << "P" << currentPID << "";
            }
            else
            {
                readyQ.push_back(current);
                current = readyQ[0];
                readyQ.erase(readyQ.begin());
                currentPID = current.PID;
                cout << "P" << currentPID << "";
            }
        }
        else 
            cout << "  ";

    }

    //print results 
    cout << endl << endl;

    for (int x = 0; x < avgBurst; x++) cout << "* ";
    cout << "\n(each star represents one ms)\n";


    cout << "|PID| " << "Arrival| " << " CPU-Burst| " << " Finish Time| "
        << "Wait Time| " << "Turnaround| " << "# of Context-Switch| \n";
    for (int j = 0; j < finished.size(); j++) {

        cout << " " << setw(5) << finished[j].PID
            << " " << setw(7) << finished[j].arrivalTime
            << " " << setw(11) << finished[j].cpuTime
            << " " << setw(10) << finished[j].completion
            << " " << setw(12)  << finished[j].waitTime
            << " " << setw(10)  << finished[j].completion - finished[j].arrivalTime;
        avgTurn = avgTurn + (finished[j].completion - finished[j].arrivalTime);
        cout << " " << setw(5) << 0 << endl;

    }



    // getting a floating exception 
    cout << fixed << setprecision(2) << "\nAverage CPU burst time = " << (float)avgBurst / finished.size() << endl;
    cout << fixed << setprecision(2) << "Average waiting time = " << (float)avgWait / finished.size() << endl;
    cout << fixed << setprecision(2) << "Average turn around time = " << (float)avgTurn / finished.size() << endl;
    cout << fixed << setprecision(2) << "Total Number of Context Switching Performed = " << (float)totalContext / finished.size() << endl << endl;
}

