*******************************************************
*  Name      :  Kerry Gip        
*  Student ID:  830354146               
*  Class     :  CSCI 3453        
*  HW#       :  2              
*  Due Date  :  3/28/2021
*******************************************************


                 Read Me


*******************************************************
*  Description of the program
*******************************************************
 This is a program that simulates a CPU scheduler which selects a process 
from a ready queue, display its actives and evaluate its performance based on measurements such as 
turn around time, avg wait time, total number of context switching. 
Simulator will print what the process looks like at run time and producing Gantt chart like outputs



*******************************************************
*  Source files
*******************************************************

Name:  main.cpp
   Main program. 

Name:  
 

Name: 
 
   
   
*******************************************************
*  Circumstances of programs
*******************************************************

   The program runs successfully on a Windows 10 desktop and on CSE Grid's built-in Putty
   My desktop build is 
   CPU: AMD RYZEN 5 3600 
   GPU: MSI RX5500XT
   RAM: 16G


   The program was developed and tested in Visual Studio Community Edition 2019 version 16.9.2
   It compiled and ran on CSE Grid's compiler running gnu g++ 6.3.1 


*******************************************************
*  How to build and run the program
*******************************************************

1. Uncompress the homework.  The homework file is compressed.  
   To uncompress it use the following commands 
       % unzip [GipLab2]

   Now you should see a directory named homework with the files:
        main.cpp
        makefile
        Readme.txt
	FCFS, RR and SRTF.jpg



2. Build the program.

    Change to the directory that contains the file by:
    % cd  

    Compile the program either way:
    % typing in the .cpp files
	a. g++ -o app main main.cpp or make 
	b. ./main sample.txt ____ (enter FCFS, RR or SRTF , for RR have a space and entier number after wars )

3. Run the program by:
   % ./app
	If using make: ./execute

4. Delete the obj files, executables, and core dump by
   %./make clean
